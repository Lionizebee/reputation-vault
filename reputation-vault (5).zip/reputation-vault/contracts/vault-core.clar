;; vault-core.clar
;; ------------------------------------------------------------------
;; Custody + routing layer for the Reputation Vault.
;;
;; Every DAO that registers here gets three internal ledgers, funded
;; automatically on each deposit according to a configurable split:
;;
;;   contributor-pool        -> paid out by payout-router.clar,
;;                               weighted by reputation.clar scores
;;   operational-reserve     -> spendable directly by the DAO admin
;;   emergency-fund-balance  -> only released via emergency-fund.clar
;;                               (time-lock + multisig)
;;
;; All STX custody lives in THIS contract. payout-router.clar and
;; emergency-fund.clar never hold funds themselves -- they are pure
;; logic contracts that are authorized to instruct vault-core to pay
;; out on their behalf. Authorization is checked with `contract-caller`,
;; which -- unlike `tx-sender` -- reflects the immediate calling
;; contract rather than the original transaction sender.
;; ------------------------------------------------------------------

(define-constant CONTRACT-OWNER tx-sender)

(define-constant ERR-NOT-ADMIN (err u100))
(define-constant ERR-DAO-EXISTS (err u101))
(define-constant ERR-NO-DAO (err u102))
(define-constant ERR-BAD-SPLIT (err u103))
(define-constant ERR-ZERO-AMOUNT (err u104))
(define-constant ERR-INSUFFICIENT-BALANCE (err u105))
(define-constant ERR-NOT-AUTHORIZED-CALLER (err u106))
(define-constant ERR-TRANSFER-FAILED (err u107))

;; basis points denominator (100.00%)
(define-constant BPS-DENOM u10000)

;; dao-id => admin + split configuration (in basis points, must sum to 10000)
(define-map daos
  { dao-id: uint }
  {
    admin: principal,
    contributor-bps: uint,
    operational-bps: uint,
    emergency-bps: uint,
    total-deposited: uint
  }
)

;; per-dao ledger balances
(define-map contributor-pool-balance { dao-id: uint } { balance: uint })
(define-map operational-reserve-balance { dao-id: uint } { balance: uint })
(define-map emergency-fund-balance { dao-id: uint } { balance: uint })

(define-data-var next-dao-id uint u1)

;; ------------------------------------------------------------------
;; Read-only helpers
;; ------------------------------------------------------------------

(define-read-only (get-dao (dao-id uint))
  (map-get? daos { dao-id: dao-id })
)

(define-read-only (get-dao-admin (dao-id uint))
  (match (map-get? daos { dao-id: dao-id })
    dao (ok (get admin dao))
    ERR-NO-DAO
  )
)

(define-read-only (get-contributor-pool-balance (dao-id uint))
  (default-to u0 (get balance (map-get? contributor-pool-balance { dao-id: dao-id })))
)

(define-read-only (get-operational-balance (dao-id uint))
  (default-to u0 (get balance (map-get? operational-reserve-balance { dao-id: dao-id })))
)

(define-read-only (get-emergency-balance (dao-id uint))
  (default-to u0 (get balance (map-get? emergency-fund-balance { dao-id: dao-id })))
)

;; ------------------------------------------------------------------
;; DAO lifecycle
;; ------------------------------------------------------------------

;; Permissionless DAO creation. Caller becomes admin.
;; Default split: 70% contributor pool / 20% operational / 10% emergency.
(define-public (register-dao (contributor-bps uint) (operational-bps uint) (emergency-bps uint))
  (let (
      (dao-id (var-get next-dao-id))
    )
    (asserts! (is-eq (+ contributor-bps (+ operational-bps emergency-bps)) BPS-DENOM) ERR-BAD-SPLIT)
    (map-set daos { dao-id: dao-id }
      {
        admin: tx-sender,
        contributor-bps: contributor-bps,
        operational-bps: operational-bps,
        emergency-bps: emergency-bps,
        total-deposited: u0
      }
    )
    (map-set contributor-pool-balance { dao-id: dao-id } { balance: u0 })
    (map-set operational-reserve-balance { dao-id: dao-id } { balance: u0 })
    (map-set emergency-fund-balance { dao-id: dao-id } { balance: u0 })
    (var-set next-dao-id (+ dao-id u1))
    (print { event: "dao-registered", dao-id: dao-id, admin: tx-sender,
             contributor-bps: contributor-bps, operational-bps: operational-bps,
             emergency-bps: emergency-bps })
    (ok dao-id)
  )
)

;; DAO admin can rebalance future splits at any time. Does not touch
;; funds already routed into existing pool balances.
(define-public (set-split-ratios (dao-id uint) (contributor-bps uint) (operational-bps uint) (emergency-bps uint))
  (let ((dao (unwrap! (map-get? daos { dao-id: dao-id }) ERR-NO-DAO)))
    (asserts! (is-eq tx-sender (get admin dao)) ERR-NOT-ADMIN)
    (asserts! (is-eq (+ contributor-bps (+ operational-bps emergency-bps)) BPS-DENOM) ERR-BAD-SPLIT)
    (map-set daos { dao-id: dao-id }
      (merge dao { contributor-bps: contributor-bps, operational-bps: operational-bps, emergency-bps: emergency-bps })
    )
    (print { event: "split-updated", dao-id: dao-id })
    (ok true)
  )
)

;; ------------------------------------------------------------------
;; Deposit + automatic split
;; ------------------------------------------------------------------

(define-public (deposit (dao-id uint) (amount uint))
  (let (
      (dao (unwrap! (map-get? daos { dao-id: dao-id }) ERR-NO-DAO))
    )
    (asserts! (> amount u0) ERR-ZERO-AMOUNT)
    (try! (stx-transfer? amount tx-sender (as-contract tx-sender)))

    (let (
        (contributor-share (/ (* amount (get contributor-bps dao)) BPS-DENOM))
        (operational-share (/ (* amount (get operational-bps dao)) BPS-DENOM))
      )
      (let (
          ;; remainder from integer division goes to emergency fund so
          ;; no satoshi-equivalent is ever lost to rounding
          (emergency-share (- amount (+ contributor-share operational-share)))
          (cur-c (get-contributor-pool-balance dao-id))
          (cur-o (get-operational-balance dao-id))
          (cur-e (get-emergency-balance dao-id))
        )
        (map-set contributor-pool-balance { dao-id: dao-id } { balance: (+ cur-c contributor-share) })
        (map-set operational-reserve-balance { dao-id: dao-id } { balance: (+ cur-o operational-share) })
        (map-set emergency-fund-balance { dao-id: dao-id } { balance: (+ cur-e emergency-share) })
        (map-set daos { dao-id: dao-id } (merge dao { total-deposited: (+ (get total-deposited dao) amount) }))

        (print { event: "deposit", dao-id: dao-id, depositor: tx-sender, amount: amount,
                 contributor-share: contributor-share, operational-share: operational-share,
                 emergency-share: emergency-share })
        (ok { contributor-share: contributor-share, operational-share: operational-share, emergency-share: emergency-share })
      )
    )
  )
)

;; ------------------------------------------------------------------
;; Spend paths -- each pool has exactly one authorized spender
;; ------------------------------------------------------------------

;; Operational reserve: spendable directly by the DAO admin, no lock.
(define-public (withdraw-operational (dao-id uint) (recipient principal) (amount uint))
  (let (
      (dao (unwrap! (map-get? daos { dao-id: dao-id }) ERR-NO-DAO))
      (bal (get-operational-balance dao-id))
    )
    (asserts! (is-eq tx-sender (get admin dao)) ERR-NOT-ADMIN)
    (asserts! (>= bal amount) ERR-INSUFFICIENT-BALANCE)
    (map-set operational-reserve-balance { dao-id: dao-id } { balance: (- bal amount) })
    (try! (as-contract (stx-transfer? amount tx-sender recipient)))
    (print { event: "operational-withdrawal", dao-id: dao-id, recipient: recipient, amount: amount })
    (ok true)
  )
)

;; Contributor pool: only the payout-router contract may trigger this,
;; and only as part of a reputation-weighted epoch distribution.
(define-public (pay-contributor (dao-id uint) (recipient principal) (amount uint))
  (let ((bal (get-contributor-pool-balance dao-id)))
    (asserts! (is-eq contract-caller .payout-router) ERR-NOT-AUTHORIZED-CALLER)
    (asserts! (>= bal amount) ERR-INSUFFICIENT-BALANCE)
    (map-set contributor-pool-balance { dao-id: dao-id } { balance: (- bal amount) })
    (try! (as-contract (stx-transfer? amount tx-sender recipient)))
    (print { event: "contributor-payout", dao-id: dao-id, recipient: recipient, amount: amount })
    (ok true)
  )
)

;; Emergency fund: only the emergency-fund contract may trigger this,
;; and only after its own time-lock + multisig checks pass.
(define-public (release-emergency (dao-id uint) (recipient principal) (amount uint))
  (let ((bal (get-emergency-balance dao-id)))
    (asserts! (is-eq contract-caller .emergency-fund) ERR-NOT-AUTHORIZED-CALLER)
    (asserts! (>= bal amount) ERR-INSUFFICIENT-BALANCE)
    (map-set emergency-fund-balance { dao-id: dao-id } { balance: (- bal amount) })
    (try! (as-contract (stx-transfer? amount tx-sender recipient)))
    (print { event: "emergency-release", dao-id: dao-id, recipient: recipient, amount: amount })
    (ok true)
  )
)
