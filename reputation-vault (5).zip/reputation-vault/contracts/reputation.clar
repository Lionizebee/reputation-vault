;; reputation.clar
;; ------------------------------------------------------------------
;; Tracks a per-DAO, per-contributor reputation score. Score is the
;; input that payout-router.clar uses to weight contributor-pool
;; distributions -- more reputation means a bigger proportional share
;; of each payout epoch, not a fixed salary.
;;
;; Reputation is:
;;   - increased by an authorized "reporter" recording a completed
;;     milestone (record-milestone)
;;   - decayed automatically if a contributor goes quiet
;;     (decay-inactive, callable by anyone, rate-limited per contributor)
;;
;; Authorization for who can record milestones is delegated to the
;; DAO's admin as registered in vault-core.clar, so there is a single
;; source of truth for "who runs this DAO."
;; ------------------------------------------------------------------

(define-constant ERR-NOT-ADMIN (err u200))
(define-constant ERR-NOT-REPORTER (err u201))
(define-constant ERR-NO-DAO (err u202))
(define-constant ERR-CONTRIBUTOR-LIST-FULL (err u203))
(define-constant ERR-NOTHING-TO-DECAY (err u204))
(define-constant ERR-TOO-SOON (err u205))

;; how many blocks of silence before a contributor's score can decay
(define-constant INACTIVITY-THRESHOLD u4320) ;; ~30 days at 10 min/block
;; decay is 10% of current score per eligible decay call
(define-constant DECAY-BPS u1000)
(define-constant BPS-DENOM u10000)
;; Note: last-updated is reset on every decay call, so INACTIVITY-THRESHOLD
;; also doubles as the minimum gap between successive decays of the same
;; contributor -- no separate cooldown constant is needed.

(define-map reporters { dao-id: uint, reporter: principal } { authorized: bool })

(define-map reputation-scores
  { dao-id: uint, contributor: principal }
  { score: uint, last-updated: uint }
)

;; capped contributor registry per DAO, used so payout-router and
;; get-total-reputation can iterate without an off-chain indexer
(define-map contributor-lists { dao-id: uint } { contributors: (list 200 principal) })

;; ------------------------------------------------------------------
;; Reporter management -- gated by the DAO admin recorded in vault-core
;; ------------------------------------------------------------------

(define-public (add-reporter (dao-id uint) (reporter principal))
  (let ((admin (unwrap! (contract-call? .vault-core get-dao-admin dao-id) ERR-NO-DAO)))
    (asserts! (is-eq tx-sender admin) ERR-NOT-ADMIN)
    (map-set reporters { dao-id: dao-id, reporter: reporter } { authorized: true })
    (print { event: "reporter-added", dao-id: dao-id, reporter: reporter })
    (ok true)
  )
)

(define-public (remove-reporter (dao-id uint) (reporter principal))
  (let ((admin (unwrap! (contract-call? .vault-core get-dao-admin dao-id) ERR-NO-DAO)))
    (asserts! (is-eq tx-sender admin) ERR-NOT-ADMIN)
    (map-set reporters { dao-id: dao-id, reporter: reporter } { authorized: false })
    (print { event: "reporter-removed", dao-id: dao-id, reporter: reporter })
    (ok true)
  )
)

(define-read-only (is-reporter (dao-id uint) (who principal))
  (default-to false (get authorized (map-get? reporters { dao-id: dao-id, reporter: who })))
)

;; ------------------------------------------------------------------
;; Internal: keep the contributor registry list up to date
;; ------------------------------------------------------------------

(define-private (ensure-registered (dao-id uint) (contributor principal))
  (let ((existing (default-to { contributors: (list) } (map-get? contributor-lists { dao-id: dao-id }))))
    (if (is-some (index-of (get contributors existing) contributor))
      (ok true)
      (match (as-max-len? (append (get contributors existing) contributor) u200)
        updated-list (begin
          (map-set contributor-lists { dao-id: dao-id } { contributors: updated-list })
          (ok true)
        )
        ERR-CONTRIBUTOR-LIST-FULL
      )
    )
  )
)

(define-read-only (get-contributors (dao-id uint))
  (default-to (list) (get contributors (map-get? contributor-lists { dao-id: dao-id })))
)

;; ------------------------------------------------------------------
;; Score reads
;; ------------------------------------------------------------------

(define-read-only (get-reputation (dao-id uint) (contributor principal))
  (default-to u0 (get score (map-get? reputation-scores { dao-id: dao-id, contributor: contributor })))
)

;; Clarity's `fold` only threads a single accumulator, so to sum scores
;; for a specific dao-id we carry the dao-id inside the accumulator
;; tuple alongside the running total.
(define-private (add-reputation (contributor principal) (acc { dao-id: uint, total: uint }))
  { dao-id: (get dao-id acc),
    total: (+ (get total acc) (get-reputation (get dao-id acc) contributor)) }
)

(define-read-only (get-total-reputation (dao-id uint))
  (get total (fold add-reputation (get-contributors dao-id) { dao-id: dao-id, total: u0 }))
)

;; ------------------------------------------------------------------
;; Milestone recording -- increases reputation
;; ------------------------------------------------------------------

(define-public (record-milestone (dao-id uint) (contributor principal) (points uint))
  (let (
      (admin (unwrap! (contract-call? .vault-core get-dao-admin dao-id) ERR-NO-DAO))
      (authorized (or (is-eq tx-sender admin) (is-reporter dao-id tx-sender)))
      (current (get-reputation dao-id contributor))
    )
    (asserts! authorized ERR-NOT-REPORTER)
    (try! (ensure-registered dao-id contributor))
    (map-set reputation-scores { dao-id: dao-id, contributor: contributor }
      { score: (+ current points), last-updated: block-height }
    )
    (print { event: "milestone-recorded", dao-id: dao-id, contributor: contributor,
             points: points, new-score: (+ current points) })
    (ok (+ current points))
  )
)

;; ------------------------------------------------------------------
;; Decay -- anyone can trigger, keeps stale reputation from dominating
;; future payout epochs indefinitely
;; ------------------------------------------------------------------

(define-public (decay-inactive (dao-id uint) (contributor principal))
  (let (
      (entry (unwrap! (map-get? reputation-scores { dao-id: dao-id, contributor: contributor }) ERR-NOTHING-TO-DECAY))
      (score (get score entry))
      (last (get last-updated entry))
    )
    (asserts! (> score u0) ERR-NOTHING-TO-DECAY)
    (asserts! (>= (- block-height last) INACTIVITY-THRESHOLD) ERR-TOO-SOON)
    (let ((decay-amount (/ (* score DECAY-BPS) BPS-DENOM)))
      (map-set reputation-scores { dao-id: dao-id, contributor: contributor }
        { score: (- score decay-amount), last-updated: block-height }
      )
      (print { event: "reputation-decayed", dao-id: dao-id, contributor: contributor,
               decayed-by: decay-amount, new-score: (- score decay-amount) })
      (ok (- score decay-amount))
    )
  )
)
