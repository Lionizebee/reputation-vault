;; payout-router.clar
;; ------------------------------------------------------------------
;; The automation layer. `distribute-epoch` is the single entry point
;; that turns the contributor-pool balance into individual payouts,
;; weighted by each contributor's reputation score relative to the
;; DAO's total reputation.
;;
;; Design choices:
;;   - Permissionless trigger: anyone can call distribute-epoch once
;;     the epoch window has elapsed. This mirrors "keeper bot" /
;;     off-chain cron patterns common in DeFi automation -- no admin
;;     needs to remember to run payroll.
;;   - Epoch-gated: enforced by block-height so it can't be spammed.
;;   - Optionally milestone-gated: if the DAO has opted into gated
;;     mode via milestone-gate.clar, distribution is blocked until an
;;     authorized reporter has unlocked that epoch's milestone flag.
;;     The flag is consumed on success so each epoch needs a fresh
;;     unlock -- this is what turns fixed payroll into outcome-based
;;     payroll.
;;   - Rounding-safe: any dust left over from integer-division shares
;;     simply remains in the contributor pool and rolls into the next
;;     epoch instead of being lost.
;; ------------------------------------------------------------------

(define-constant ERR-NO-DAO (err u400))
(define-constant ERR-TOO-SOON (err u401))
(define-constant ERR-GATED-AND-LOCKED (err u402))
(define-constant ERR-NOTHING-TO-DISTRIBUTE (err u403))

;; ~30 days at an assumed 10 min/block; tune per deployment
(define-constant EPOCH-LENGTH u4320)

(define-map epoch-state { dao-id: uint } { last-distributed: uint, epoch-count: uint })

(define-read-only (get-epoch-state (dao-id uint))
  (default-to { last-distributed: u0, epoch-count: u0 } (map-get? epoch-state { dao-id: dao-id }))
)

(define-read-only (blocks-until-next-epoch (dao-id uint))
  (let (
      (state (get-epoch-state dao-id))
      (next-eligible (+ (get last-distributed state) EPOCH-LENGTH))
    )
    (if (>= block-height next-eligible) u0 (- next-eligible block-height))
  )
)

(define-private (pay-share (contributor principal) (acc { dao-id: uint, total-rep: uint, pool: uint, paid: uint }))
  (let ((rep (contract-call? .reputation get-reputation (get dao-id acc) contributor)))
    (if (> rep u0)
      (let ((share (/ (* (get pool acc) rep) (get total-rep acc))))
        (if (> share u0)
          (begin
            (unwrap-panic (contract-call? .vault-core pay-contributor (get dao-id acc) contributor share))
            (merge acc { paid: (+ (get paid acc) share) })
          )
          acc
        )
      )
      acc
    )
  )
)

(define-public (distribute-epoch (dao-id uint))
  (let (
      (admin-check (unwrap! (contract-call? .vault-core get-dao-admin dao-id) ERR-NO-DAO))
      (state (get-epoch-state dao-id))
      (pool (contract-call? .vault-core get-contributor-pool-balance dao-id))
      (total-rep (contract-call? .reputation get-total-reputation dao-id))
      (contributors (contract-call? .reputation get-contributors dao-id))
      (gated (contract-call? .milestone-gate is-gated dao-id))
    )
    (asserts! (or (is-eq (get epoch-count state) u0)
                  (>= block-height (+ (get last-distributed state) EPOCH-LENGTH)))
              ERR-TOO-SOON)
    (asserts! (> pool u0) ERR-NOTHING-TO-DISTRIBUTE)
    (asserts! (> total-rep u0) ERR-NOTHING-TO-DISTRIBUTE)
    (if gated
      (asserts! (contract-call? .milestone-gate is-unlocked dao-id) ERR-GATED-AND-LOCKED)
      true
    )

    (let ((result (fold pay-share contributors { dao-id: dao-id, total-rep: total-rep, pool: pool, paid: u0 })))
      (map-set epoch-state { dao-id: dao-id }
        { last-distributed: block-height, epoch-count: (+ (get epoch-count state) u1) }
      )
      (if gated
        (unwrap-panic (contract-call? .milestone-gate consume-unlock dao-id))
        true
      )
      (print { event: "epoch-distributed", dao-id: dao-id, total-paid: (get paid result),
               contributor-count: (len contributors), epoch: (+ (get epoch-count state) u1) })
      (ok (get paid result))
    )
  )
)
