;; milestone-gate.clar
;; ------------------------------------------------------------------
;; Optional event-triggered gate on top of the payout epoch cycle.
;;
;; A DAO can opt into "gated mode": the contributor-pool distribution
;; in payout-router.clar will refuse to run until this contract's
;; milestone flag has been explicitly unlocked by an authorized
;; reporter for that epoch. This turns a plain time-based payroll
;; into an outcome-based one -- e.g. "ship the release" or "hit the
;; funding target" before the team gets paid.
;;
;; Once consumed by a successful distribution, the flag automatically
;; re-locks so the next epoch requires a fresh unlock.
;; ------------------------------------------------------------------

(define-constant ERR-NOT-ADMIN (err u300))
(define-constant ERR-NOT-REPORTER (err u301))
(define-constant ERR-NO-DAO (err u302))
(define-constant ERR-NOT-AUTHORIZED-CALLER (err u303))

(define-map gate-config { dao-id: uint } { gated: bool })
(define-map milestone-flags { dao-id: uint } { unlocked: bool, note: (string-ascii 140) })

(define-public (set-gated (dao-id uint) (gated bool))
  (let ((admin (unwrap! (contract-call? .vault-core get-dao-admin dao-id) ERR-NO-DAO)))
    (asserts! (is-eq tx-sender admin) ERR-NOT-ADMIN)
    (map-set gate-config { dao-id: dao-id } { gated: gated })
    (print { event: "gate-config-updated", dao-id: dao-id, gated: gated })
    (ok true)
  )
)

(define-read-only (is-gated (dao-id uint))
  (default-to false (get gated (map-get? gate-config { dao-id: dao-id })))
)

;; Authorized reporters (shared authorization with reputation.clar's
;; admin-controlled model) can flip the milestone flag once the
;; off-chain or oracle-verified condition has been met.
(define-public (unlock-milestone (dao-id uint) (note (string-ascii 140)))
  (let (
      (admin (unwrap! (contract-call? .vault-core get-dao-admin dao-id) ERR-NO-DAO))
      (authorized (or (is-eq tx-sender admin) (contract-call? .reputation is-reporter dao-id tx-sender)))
    )
    (asserts! authorized ERR-NOT-REPORTER)
    (map-set milestone-flags { dao-id: dao-id } { unlocked: true, note: note })
    (print { event: "milestone-unlocked", dao-id: dao-id, note: note })
    (ok true)
  )
)

(define-read-only (is-unlocked (dao-id uint))
  (default-to false (get unlocked (map-get? milestone-flags { dao-id: dao-id })))
)

;; Called only by payout-router.clar immediately after a successful
;; gated distribution, so each epoch needs its own fresh unlock.
(define-public (consume-unlock (dao-id uint))
  (begin
    (asserts! (is-eq contract-caller .payout-router) ERR-NOT-AUTHORIZED-CALLER)
    (map-set milestone-flags { dao-id: dao-id } { unlocked: false, note: "" })
    (ok true)
  )
)
