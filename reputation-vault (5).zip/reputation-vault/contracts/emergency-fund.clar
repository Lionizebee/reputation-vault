;; emergency-fund.clar
;; ------------------------------------------------------------------
;; The highest-friction pool in the vault. Emergency-fund balances
;; accumulate automatically from every deposit's split (see
;; vault-core.clar) but can only leave the vault when BOTH:
;;
;;   1. A minimum block-height lock has elapsed since the release was
;;      first proposed (MIN-LOCK-BLOCKS), AND
;;   2. At least `threshold` of the DAO's designated signers have
;;      approved that specific proposal (amount + recipient + dao-id).
;;
;; This is deliberately separate from payout-router's fast, permission-
;; less epoch cycle -- emergency funds are meant to be hard to move.
;; ------------------------------------------------------------------

(define-constant ERR-NOT-ADMIN (err u500))
(define-constant ERR-NO-DAO (err u501))
(define-constant ERR-ALREADY-SIGNER (err u502))
(define-constant ERR-NOT-SIGNER (err u503))
(define-constant ERR-NO-PROPOSAL (err u504))
(define-constant ERR-ALREADY-APPROVED (err u505))
(define-constant ERR-LOCK-NOT-ELAPSED (err u506))
(define-constant ERR-THRESHOLD-NOT-MET (err u507))
(define-constant ERR-ALREADY-EXECUTED (err u508))
(define-constant ERR-BAD-THRESHOLD (err u509))

;; minimum blocks a proposal must wait before it can be executed,
;; regardless of how fast approvals come in
(define-constant MIN-LOCK-BLOCKS u1008) ;; ~1 week at 10 min/block

(define-map multisig-config { dao-id: uint } { threshold: uint, signer-count: uint })
(define-map signers { dao-id: uint, signer: principal } { active: bool })

(define-map proposals
  { dao-id: uint, proposal-id: uint }
  {
    recipient: principal,
    amount: uint,
    proposed-at: uint,
    approvals: uint,
    executed: bool
  }
)
(define-map proposal-approvals { dao-id: uint, proposal-id: uint, signer: principal } { approved: bool })
(define-map next-proposal-id { dao-id: uint } { id: uint })

;; ------------------------------------------------------------------
;; Multisig configuration -- DAO admin only
;; ------------------------------------------------------------------

(define-public (configure-multisig (dao-id uint) (threshold uint))
  (let ((admin (unwrap! (contract-call? .vault-core get-dao-admin dao-id) ERR-NO-DAO)))
    (asserts! (is-eq tx-sender admin) ERR-NOT-ADMIN)
    (asserts! (> threshold u0) ERR-BAD-THRESHOLD)
    (map-set multisig-config { dao-id: dao-id }
      { threshold: threshold, signer-count: (default-to u0 (get signer-count (map-get? multisig-config { dao-id: dao-id }))) }
    )
    (ok true)
  )
)

(define-public (add-signer (dao-id uint) (signer principal))
  (let (
      (admin (unwrap! (contract-call? .vault-core get-dao-admin dao-id) ERR-NO-DAO))
      (config (default-to { threshold: u1, signer-count: u0 } (map-get? multisig-config { dao-id: dao-id })))
      (already (default-to false (get active (map-get? signers { dao-id: dao-id, signer: signer }))))
    )
    (asserts! (is-eq tx-sender admin) ERR-NOT-ADMIN)
    (asserts! (not already) ERR-ALREADY-SIGNER)
    (map-set signers { dao-id: dao-id, signer: signer } { active: true })
    (map-set multisig-config { dao-id: dao-id } (merge config { signer-count: (+ (get signer-count config) u1) }))
    (print { event: "signer-added", dao-id: dao-id, signer: signer })
    (ok true)
  )
)

(define-read-only (is-signer (dao-id uint) (who principal))
  (default-to false (get active (map-get? signers { dao-id: dao-id, signer: who })))
)

;; ------------------------------------------------------------------
;; Proposal lifecycle
;; ------------------------------------------------------------------

(define-public (propose-release (dao-id uint) (recipient principal) (amount uint))
  (let (
      (admin (unwrap! (contract-call? .vault-core get-dao-admin dao-id) ERR-NO-DAO))
      (proposal-id (default-to u1 (get id (map-get? next-proposal-id { dao-id: dao-id }))))
    )
    (asserts! (or (is-eq tx-sender admin) (is-signer dao-id tx-sender)) ERR-NOT-SIGNER)
    (map-set proposals { dao-id: dao-id, proposal-id: proposal-id }
      { recipient: recipient, amount: amount, proposed-at: block-height, approvals: u0, executed: false }
    )
    (map-set next-proposal-id { dao-id: dao-id } { id: (+ proposal-id u1) })
    (print { event: "emergency-release-proposed", dao-id: dao-id, proposal-id: proposal-id,
             recipient: recipient, amount: amount, unlocks-at: (+ block-height MIN-LOCK-BLOCKS) })
    (ok proposal-id)
  )
)

(define-public (approve-release (dao-id uint) (proposal-id uint))
  (let (
      (proposal (unwrap! (map-get? proposals { dao-id: dao-id, proposal-id: proposal-id }) ERR-NO-PROPOSAL))
      (already (default-to false (get approved (map-get? proposal-approvals { dao-id: dao-id, proposal-id: proposal-id, signer: tx-sender }))))
    )
    (asserts! (is-signer dao-id tx-sender) ERR-NOT-SIGNER)
    (asserts! (not already) ERR-ALREADY-APPROVED)
    (asserts! (not (get executed proposal)) ERR-ALREADY-EXECUTED)
    (map-set proposal-approvals { dao-id: dao-id, proposal-id: proposal-id, signer: tx-sender } { approved: true })
    (map-set proposals { dao-id: dao-id, proposal-id: proposal-id }
      (merge proposal { approvals: (+ (get approvals proposal) u1) })
    )
    (print { event: "emergency-release-approved", dao-id: dao-id, proposal-id: proposal-id, signer: tx-sender })
    (ok (+ (get approvals proposal) u1))
  )
)

(define-public (execute-release (dao-id uint) (proposal-id uint))
  (let (
      (proposal (unwrap! (map-get? proposals { dao-id: dao-id, proposal-id: proposal-id }) ERR-NO-PROPOSAL))
      (config (unwrap! (map-get? multisig-config { dao-id: dao-id }) ERR-NO-DAO))
    )
    (asserts! (not (get executed proposal)) ERR-ALREADY-EXECUTED)
    (asserts! (>= block-height (+ (get proposed-at proposal) MIN-LOCK-BLOCKS)) ERR-LOCK-NOT-ELAPSED)
    (asserts! (>= (get approvals proposal) (get threshold config)) ERR-THRESHOLD-NOT-MET)
    (map-set proposals { dao-id: dao-id, proposal-id: proposal-id } (merge proposal { executed: true }))
    (try! (contract-call? .vault-core release-emergency dao-id (get recipient proposal) (get amount proposal)))
    (print { event: "emergency-release-executed", dao-id: dao-id, proposal-id: proposal-id })
    (ok true)
  )
)

(define-read-only (get-proposal (dao-id uint) (proposal-id uint))
  (map-get? proposals { dao-id: dao-id, proposal-id: proposal-id })
)
