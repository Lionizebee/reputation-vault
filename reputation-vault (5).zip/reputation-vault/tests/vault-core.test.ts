import { describe, expect, it, beforeEach } from "vitest";
import { Cl } from "@stacks/transactions";

// `simnet` is injected globally by vitest-environment-clarinet
const accounts = simnet.getAccounts();
const deployer = accounts.get("deployer")!;
const admin = accounts.get("wallet_1")!;
const funder = accounts.get("wallet_2")!;
const contributorA = accounts.get("wallet_3")!;

describe("vault-core: DAO registration + split configuration", () => {
  it("registers a DAO with a valid basis-point split and returns dao-id 1", () => {
    const res = simnet.callPublicFn(
      "vault-core",
      "register-dao",
      [Cl.uint(7000), Cl.uint(2000), Cl.uint(1000)],
      admin
    );
    expect(res.result).toBeOk(Cl.uint(1));
  });

  it("rejects a split that does not sum to 10000 basis points", () => {
    const res = simnet.callPublicFn(
      "vault-core",
      "register-dao",
      [Cl.uint(7000), Cl.uint(2000), Cl.uint(500)], // sums to 9500
      admin
    );
    expect(res.result).toBeErr(Cl.uint(103)); // ERR-BAD-SPLIT
  });

  it("only the DAO admin can update split ratios", () => {
    simnet.callPublicFn("vault-core", "register-dao", [Cl.uint(5000), Cl.uint(3000), Cl.uint(2000)], admin);
    const badActor = simnet.callPublicFn(
      "vault-core",
      "set-split-ratios",
      [Cl.uint(1), Cl.uint(1000), Cl.uint(1000), Cl.uint(8000)],
      funder
    );
    expect(badActor.result).toBeErr(Cl.uint(100)); // ERR-NOT-ADMIN

    const goodActor = simnet.callPublicFn(
      "vault-core",
      "set-split-ratios",
      [Cl.uint(1), Cl.uint(6000), Cl.uint(3000), Cl.uint(1000)],
      admin
    );
    expect(goodActor.result).toBeOk(Cl.bool(true));
  });
});

describe("vault-core: deposit splitting math", () => {
  beforeEach(() => {
    simnet.callPublicFn("vault-core", "register-dao", [Cl.uint(7000), Cl.uint(2000), Cl.uint(1000)], admin);
  });

  it("splits a clean deposit exactly across the three pools", () => {
    const res = simnet.callPublicFn("vault-core", "deposit", [Cl.uint(1), Cl.uint(100_000_000)], funder);
    expect(res.result).toBeOk(
      Cl.tuple({
        "contributor-share": Cl.uint(70_000_000),
        "operational-share": Cl.uint(20_000_000),
        "emergency-share": Cl.uint(10_000_000),
      })
    );
  });

  it("routes integer-division rounding dust into the emergency fund so no unit is lost", () => {
    // 100_000_007 * 7000 / 10000 = 70000004.9 -> floors to 70000004
    // 100_000_007 * 2000 / 10000 = 20000001.4 -> floors to 20000001
    // remainder must land in emergency so total still equals the deposit
    simnet.callPublicFn("vault-core", "deposit", [Cl.uint(1), Cl.uint(100_000_007)], funder);

    const contributorBal = simnet.callReadOnlyFn("vault-core", "get-contributor-pool-balance", [Cl.uint(1)], funder);
    const operationalBal = simnet.callReadOnlyFn("vault-core", "get-operational-balance", [Cl.uint(1)], funder);
    const emergencyBal = simnet.callReadOnlyFn("vault-core", "get-emergency-balance", [Cl.uint(1)], funder);

    const c = Number((contributorBal.result as any).value);
    const o = Number((operationalBal.result as any).value);
    const e = Number((emergencyBal.result as any).value);

    expect(c + o + e).toBe(100_000_007);
  });

  it("rejects a zero-amount deposit", () => {
    const res = simnet.callPublicFn("vault-core", "deposit", [Cl.uint(1), Cl.uint(0)], funder);
    expect(res.result).toBeErr(Cl.uint(104)); // ERR-ZERO-AMOUNT
  });

  it("rejects deposits to a nonexistent dao-id", () => {
    const res = simnet.callPublicFn("vault-core", "deposit", [Cl.uint(999), Cl.uint(1000)], funder);
    expect(res.result).toBeErr(Cl.uint(102)); // ERR-NO-DAO
  });
});

describe("vault-core: operational withdrawals", () => {
  beforeEach(() => {
    simnet.callPublicFn("vault-core", "register-dao", [Cl.uint(7000), Cl.uint(2000), Cl.uint(1000)], admin);
    simnet.callPublicFn("vault-core", "deposit", [Cl.uint(1), Cl.uint(100_000_000)], funder);
  });

  it("lets the admin withdraw from operational reserve within balance", () => {
    const res = simnet.callPublicFn(
      "vault-core",
      "withdraw-operational",
      [Cl.uint(1), Cl.principal(contributorA), Cl.uint(5_000_000)],
      admin
    );
    expect(res.result).toBeOk(Cl.bool(true));
  });

  it("blocks non-admin operational withdrawals", () => {
    const res = simnet.callPublicFn(
      "vault-core",
      "withdraw-operational",
      [Cl.uint(1), Cl.principal(contributorA), Cl.uint(1_000_000)],
      funder
    );
    expect(res.result).toBeErr(Cl.uint(100)); // ERR-NOT-ADMIN
  });

  it("blocks withdrawals that exceed the operational balance", () => {
    const res = simnet.callPublicFn(
      "vault-core",
      "withdraw-operational",
      [Cl.uint(1), Cl.principal(contributorA), Cl.uint(999_000_000)],
      admin
    );
    expect(res.result).toBeErr(Cl.uint(105)); // ERR-INSUFFICIENT-BALANCE
  });

  it("blocks direct calls to pay-contributor from anyone but payout-router", () => {
    const res = simnet.callPublicFn(
      "vault-core",
      "pay-contributor",
      [Cl.uint(1), Cl.principal(contributorA), Cl.uint(1_000_000)],
      admin
    );
    expect(res.result).toBeErr(Cl.uint(106)); // ERR-NOT-AUTHORIZED-CALLER
  });

  it("blocks direct calls to release-emergency from anyone but emergency-fund", () => {
    const res = simnet.callPublicFn(
      "vault-core",
      "release-emergency",
      [Cl.uint(1), Cl.principal(contributorA), Cl.uint(1_000_000)],
      admin
    );
    expect(res.result).toBeErr(Cl.uint(106)); // ERR-NOT-AUTHORIZED-CALLER
  });
});
