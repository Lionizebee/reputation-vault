import { describe, expect, it, beforeEach } from "vitest";
import { Cl } from "@stacks/transactions";

const accounts = simnet.getAccounts();
const admin = accounts.get("wallet_1")!;
const funder = accounts.get("wallet_2")!;
const contributorA = accounts.get("wallet_3")!;
const contributorB = accounts.get("wallet_4")!;
const anyone = accounts.get("wallet_5")!;

function setupDaoWithContributors() {
  simnet.callPublicFn("vault-core", "register-dao", [Cl.uint(7000), Cl.uint(2000), Cl.uint(1000)], admin);
  simnet.callPublicFn("vault-core", "deposit", [Cl.uint(1), Cl.uint(100_000_000)], funder);
  // 30/70 reputation split between A and B
  simnet.callPublicFn("reputation", "record-milestone", [Cl.uint(1), Cl.principal(contributorA), Cl.uint(30)], admin);
  simnet.callPublicFn("reputation", "record-milestone", [Cl.uint(1), Cl.principal(contributorB), Cl.uint(70)], admin);
}

describe("payout-router: epoch gating", () => {
  beforeEach(() => setupDaoWithContributors());

  it("allows the first distribute-epoch call for a fresh DAO", () => {
    const res = simnet.callPublicFn("payout-router", "distribute-epoch", [Cl.uint(1)], anyone);
    // pool = 70,000,000 (70% of 100,000,000 deposit); with a clean 30/70
    // reputation split, the full pool divides evenly with no dust.
    expect(res.result).toBeOk(Cl.uint(70_000_000));
  });

  it("blocks a second distribute-epoch call before the epoch window elapses", () => {
    simnet.callPublicFn("payout-router", "distribute-epoch", [Cl.uint(1)], anyone);
    simnet.callPublicFn("vault-core", "deposit", [Cl.uint(1), Cl.uint(100_000_000)], funder);
    const res = simnet.callPublicFn("payout-router", "distribute-epoch", [Cl.uint(1)], anyone);
    expect(res.result).toBeErr(Cl.uint(401)); // ERR-TOO-SOON
  });

  it("is permissionless -- any principal can trigger a valid epoch distribution", () => {
    const res = simnet.callPublicFn("payout-router", "distribute-epoch", [Cl.uint(1)], anyone);
    expect(res.result.type).toBe(7); // ResponseOk
  });
});

describe("payout-router: reputation-weighted payout math", () => {
  beforeEach(() => setupDaoWithContributors());

  it("pays contributors proportionally to their reputation share of the pool", () => {
    simnet.callPublicFn("payout-router", "distribute-epoch", [Cl.uint(1)], anyone);

    // contributor pool = 70,000,000 (70% of 100,000,000)
    // total reputation = 100 (30 + 70)
    // A's share = 70,000,000 * 30 / 100 = 21,000,000
    // B's share = 70,000,000 * 70 / 100 = 49,000,000
    const remainingPool = simnet.callReadOnlyFn("vault-core", "get-contributor-pool-balance", [Cl.uint(1)], anyone);
    // 70,000,000 - 21,000,000 - 49,000,000 = 0 remaining (clean division in this example)
    expect(remainingPool.result).toBeUint(0);
  });

  it("refuses to distribute when the contributor pool is empty", () => {
    simnet.callPublicFn("vault-core", "register-dao", [Cl.uint(7000), Cl.uint(2000), Cl.uint(1000)], admin);
    simnet.callPublicFn("reputation", "record-milestone", [Cl.uint(2), Cl.principal(contributorA), Cl.uint(10)], admin);
    const res = simnet.callPublicFn("payout-router", "distribute-epoch", [Cl.uint(2)], anyone);
    expect(res.result).toBeErr(Cl.uint(403)); // ERR-NOTHING-TO-DISTRIBUTE
  });

  it("refuses to distribute when no contributor has any reputation yet", () => {
    simnet.callPublicFn("vault-core", "register-dao", [Cl.uint(7000), Cl.uint(2000), Cl.uint(1000)], admin);
    simnet.callPublicFn("vault-core", "deposit", [Cl.uint(2), Cl.uint(50_000_000)], funder);
    const res = simnet.callPublicFn("payout-router", "distribute-epoch", [Cl.uint(2)], anyone);
    expect(res.result).toBeErr(Cl.uint(403)); // ERR-NOTHING-TO-DISTRIBUTE
  });
});

describe("payout-router: milestone gating", () => {
  beforeEach(() => setupDaoWithContributors());

  it("blocks distribution when gated mode is on and the milestone is locked", () => {
    simnet.callPublicFn("milestone-gate", "set-gated", [Cl.uint(1), Cl.bool(true)], admin);
    const res = simnet.callPublicFn("payout-router", "distribute-epoch", [Cl.uint(1)], anyone);
    expect(res.result).toBeErr(Cl.uint(402)); // ERR-GATED-AND-LOCKED
  });

  it("allows distribution once the milestone is unlocked, then re-locks it for the next epoch", () => {
    simnet.callPublicFn("milestone-gate", "set-gated", [Cl.uint(1), Cl.bool(true)], admin);
    simnet.callPublicFn("milestone-gate", "unlock-milestone", [Cl.uint(1), Cl.stringAscii("shipped v1")], admin);

    const res = simnet.callPublicFn("payout-router", "distribute-epoch", [Cl.uint(1)], anyone);
    expect(res.result.type).toBe(7); // ResponseOk

    const stillUnlocked = simnet.callReadOnlyFn("milestone-gate", "is-unlocked", [Cl.uint(1)], anyone);
    expect(stillUnlocked.result).toBeBool(false);
  });
});
