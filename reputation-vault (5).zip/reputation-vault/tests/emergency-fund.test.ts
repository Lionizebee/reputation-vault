import { describe, expect, it, beforeEach } from "vitest";
import { Cl } from "@stacks/transactions";

const accounts = simnet.getAccounts();
const admin = accounts.get("wallet_1")!;
const funder = accounts.get("wallet_2")!;
const signer1 = accounts.get("wallet_3")!;
const signer2 = accounts.get("wallet_4")!;
const recipient = accounts.get("wallet_5")!;
const outsider = accounts.get("wallet_6")!;

function setupDaoWithEmergencyFunds() {
  simnet.callPublicFn("vault-core", "register-dao", [Cl.uint(7000), Cl.uint(2000), Cl.uint(1000)], admin);
  simnet.callPublicFn("vault-core", "deposit", [Cl.uint(1), Cl.uint(100_000_000)], funder); // 10M -> emergency
  simnet.callPublicFn("emergency-fund", "configure-multisig", [Cl.uint(1), Cl.uint(2)], admin); // 2-of-N
  simnet.callPublicFn("emergency-fund", "add-signer", [Cl.uint(1), Cl.principal(signer1)], admin);
  simnet.callPublicFn("emergency-fund", "add-signer", [Cl.uint(1), Cl.principal(signer2)], admin);
}

describe("emergency-fund: proposal + approval lifecycle", () => {
  beforeEach(() => setupDaoWithEmergencyFunds());

  it("lets the admin or a signer propose a release", () => {
    const res = simnet.callPublicFn(
      "emergency-fund",
      "propose-release",
      [Cl.uint(1), Cl.principal(recipient), Cl.uint(5_000_000)],
      admin
    );
    expect(res.result).toBeOk(Cl.uint(1));
  });

  it("blocks a non-signer, non-admin from proposing", () => {
    const res = simnet.callPublicFn(
      "emergency-fund",
      "propose-release",
      [Cl.uint(1), Cl.principal(recipient), Cl.uint(1_000_000)],
      outsider
    );
    expect(res.result).toBeErr(Cl.uint(503)); // ERR-NOT-SIGNER
  });

  it("blocks execution before the time-lock has elapsed even with enough approvals", () => {
    simnet.callPublicFn("emergency-fund", "propose-release", [Cl.uint(1), Cl.principal(recipient), Cl.uint(5_000_000)], admin);
    simnet.callPublicFn("emergency-fund", "approve-release", [Cl.uint(1), Cl.uint(1)], signer1);
    simnet.callPublicFn("emergency-fund", "approve-release", [Cl.uint(1), Cl.uint(1)], signer2);

    const res = simnet.callPublicFn("emergency-fund", "execute-release", [Cl.uint(1), Cl.uint(1)], admin);
    expect(res.result).toBeErr(Cl.uint(506)); // ERR-LOCK-NOT-ELAPSED
  });

  it("blocks execution when approval threshold is not met, even after the lock elapses", () => {
    simnet.callPublicFn("emergency-fund", "propose-release", [Cl.uint(1), Cl.principal(recipient), Cl.uint(5_000_000)], admin);
    simnet.callPublicFn("emergency-fund", "approve-release", [Cl.uint(1), Cl.uint(1)], signer1); // only 1 of 2 needed

    simnet.mineEmptyBlocks(1009); // > MIN-LOCK-BLOCKS (1008)
    const res = simnet.callPublicFn("emergency-fund", "execute-release", [Cl.uint(1), Cl.uint(1)], admin);
    expect(res.result).toBeErr(Cl.uint(507)); // ERR-THRESHOLD-NOT-MET
  });

  it("executes successfully once both the time-lock and approval threshold are satisfied", () => {
    simnet.callPublicFn("emergency-fund", "propose-release", [Cl.uint(1), Cl.principal(recipient), Cl.uint(5_000_000)], admin);
    simnet.callPublicFn("emergency-fund", "approve-release", [Cl.uint(1), Cl.uint(1)], signer1);
    simnet.callPublicFn("emergency-fund", "approve-release", [Cl.uint(1), Cl.uint(1)], signer2);
    simnet.mineEmptyBlocks(1009);

    const res = simnet.callPublicFn("emergency-fund", "execute-release", [Cl.uint(1), Cl.uint(1)], admin);
    expect(res.result).toBeOk(Cl.bool(true));

    const remaining = simnet.callReadOnlyFn("vault-core", "get-emergency-balance", [Cl.uint(1)], admin);
    expect(remaining.result).toBeUint(5_000_000); // 10,000,000 - 5,000,000
  });

  it("blocks a signer from approving the same proposal twice", () => {
    simnet.callPublicFn("emergency-fund", "propose-release", [Cl.uint(1), Cl.principal(recipient), Cl.uint(5_000_000)], admin);
    simnet.callPublicFn("emergency-fund", "approve-release", [Cl.uint(1), Cl.uint(1)], signer1);
    const res = simnet.callPublicFn("emergency-fund", "approve-release", [Cl.uint(1), Cl.uint(1)], signer1);
    expect(res.result).toBeErr(Cl.uint(505)); // ERR-ALREADY-APPROVED
  });

  it("blocks direct calls to vault-core release-emergency from outside the emergency-fund contract", () => {
    const res = simnet.callPublicFn(
      "vault-core",
      "release-emergency",
      [Cl.uint(1), Cl.principal(recipient), Cl.uint(1_000_000)],
      admin
    );
    expect(res.result).toBeErr(Cl.uint(106)); // ERR-NOT-AUTHORIZED-CALLER
  });
});
