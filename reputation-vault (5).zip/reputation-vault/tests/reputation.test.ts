import { describe, expect, it, beforeEach } from "vitest";
import { Cl } from "@stacks/transactions";

const accounts = simnet.getAccounts();
const admin = accounts.get("wallet_1")!;
const reporter = accounts.get("wallet_2")!;
const contributorA = accounts.get("wallet_3")!;
const contributorB = accounts.get("wallet_4")!;
const outsider = accounts.get("wallet_5")!;

describe("reputation: reporter authorization", () => {
  beforeEach(() => {
    simnet.callPublicFn("vault-core", "register-dao", [Cl.uint(7000), Cl.uint(2000), Cl.uint(1000)], admin);
  });

  it("lets the DAO admin add a reporter", () => {
    const res = simnet.callPublicFn("reputation", "add-reporter", [Cl.uint(1), Cl.principal(reporter)], admin);
    expect(res.result).toBeOk(Cl.bool(true));
  });

  it("blocks a non-admin from adding a reporter", () => {
    const res = simnet.callPublicFn("reputation", "add-reporter", [Cl.uint(1), Cl.principal(reporter)], outsider);
    expect(res.result).toBeErr(Cl.uint(200)); // ERR-NOT-ADMIN
  });

  it("blocks milestone recording from an unauthorized principal", () => {
    const res = simnet.callPublicFn(
      "reputation",
      "record-milestone",
      [Cl.uint(1), Cl.principal(contributorA), Cl.uint(50)],
      outsider
    );
    expect(res.result).toBeErr(Cl.uint(201)); // ERR-NOT-REPORTER
  });

  it("allows the admin itself to record milestones without being added as a reporter", () => {
    const res = simnet.callPublicFn(
      "reputation",
      "record-milestone",
      [Cl.uint(1), Cl.principal(contributorA), Cl.uint(50)],
      admin
    );
    expect(res.result).toBeOk(Cl.uint(50));
  });
});

describe("reputation: milestone accumulation + contributor registry", () => {
  beforeEach(() => {
    simnet.callPublicFn("vault-core", "register-dao", [Cl.uint(7000), Cl.uint(2000), Cl.uint(1000)], admin);
    simnet.callPublicFn("reputation", "add-reporter", [Cl.uint(1), Cl.principal(reporter)], admin);
  });

  it("accumulates points across multiple milestones for the same contributor", () => {
    simnet.callPublicFn("reputation", "record-milestone", [Cl.uint(1), Cl.principal(contributorA), Cl.uint(30)], reporter);
    const res = simnet.callPublicFn(
      "reputation",
      "record-milestone",
      [Cl.uint(1), Cl.principal(contributorA), Cl.uint(20)],
      reporter
    );
    expect(res.result).toBeOk(Cl.uint(50));
  });

  it("registers a contributor exactly once in the contributor list across repeated milestones", () => {
    simnet.callPublicFn("reputation", "record-milestone", [Cl.uint(1), Cl.principal(contributorA), Cl.uint(10)], reporter);
    simnet.callPublicFn("reputation", "record-milestone", [Cl.uint(1), Cl.principal(contributorA), Cl.uint(10)], reporter);
    const list = simnet.callReadOnlyFn("reputation", "get-contributors", [Cl.uint(1)], reporter);
    const listVal = (list.result as any).list;
    expect(listVal.length).toBe(1);
  });

  it("computes total reputation across multiple contributors correctly", () => {
    simnet.callPublicFn("reputation", "record-milestone", [Cl.uint(1), Cl.principal(contributorA), Cl.uint(40)], reporter);
    simnet.callPublicFn("reputation", "record-milestone", [Cl.uint(1), Cl.principal(contributorB), Cl.uint(60)], reporter);
    const total = simnet.callReadOnlyFn("reputation", "get-total-reputation", [Cl.uint(1)], reporter);
    expect(total.result).toBeUint(100);
  });
});

describe("reputation: decay", () => {
  beforeEach(() => {
    simnet.callPublicFn("vault-core", "register-dao", [Cl.uint(7000), Cl.uint(2000), Cl.uint(1000)], admin);
    simnet.callPublicFn("reputation", "add-reporter", [Cl.uint(1), Cl.principal(reporter)], admin);
    simnet.callPublicFn("reputation", "record-milestone", [Cl.uint(1), Cl.principal(contributorA), Cl.uint(100)], reporter);
  });

  it("refuses to decay before the inactivity threshold has elapsed", () => {
    const res = simnet.callPublicFn("reputation", "decay-inactive", [Cl.uint(1), Cl.principal(contributorA)], outsider);
    expect(res.result).toBeErr(Cl.uint(205)); // ERR-TOO-SOON
  });

  it("decays score by 10% once the inactivity threshold has elapsed, callable by anyone", () => {
    simnet.mineEmptyBlocks(4321); // > INACTIVITY-THRESHOLD (4320)
    const res = simnet.callPublicFn("reputation", "decay-inactive", [Cl.uint(1), Cl.principal(contributorA)], outsider);
    expect(res.result).toBeOk(Cl.uint(90)); // 100 - 10%
  });
});
