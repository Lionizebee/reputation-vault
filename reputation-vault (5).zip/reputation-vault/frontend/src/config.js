// Fill these in after `clarinet deployments generate` / a testnet deploy.
// The demo UI reads them to build contract-call requests.
export const NETWORK = "testnet"; // "testnet" | "mainnet" | "devnet"
export const CONTRACT_ADDRESS = "ST25HBNK2PKDND65BXTGV8AP6NHE967GFS7KGDVYG"; // live testnet deployer address
export const CONTRACT_NAMES = {
  vault: "vault-core",
  reputation: "reputation",
  payoutRouter: "payout-router",
  emergencyFund: "emergency-fund",
  milestoneGate: "milestone-gate",
};

// microSTX per STX, used purely for display formatting in the UI
export const MICRO_STX = 1_000_000;
