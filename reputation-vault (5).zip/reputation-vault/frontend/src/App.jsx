import React, { useState } from "react";
import { connect, request, isConnected } from "@stacks/connect";
import { Cl, cvToJSON, uintCV, principalCV, standardPrincipalCV } from "@stacks/transactions";
import { CONTRACT_ADDRESS, CONTRACT_NAMES, MICRO_STX } from "./config.js";

// This UI is intentionally thin. It exists only to demonstrate that the
// contract-level financial behaviors -- split routing, reputation-weighted
// payout, milestone gating, emergency multisig -- are real and callable.
// The judged logic lives in /contracts, not here.

function Section({ title, children }) {
  return (
    <section style={{ marginBottom: "2rem", padding: "1rem", border: "1px solid #333", borderRadius: 8 }}>
      <h2 style={{ marginTop: 0 }}>{title}</h2>
      {children}
    </section>
  );
}

export default function App() {
  const [connected, setConnected] = useState(false);
  const [address, setAddress] = useState("");
  const [daoId, setDaoId] = useState("1");
  const [depositAmount, setDepositAmount] = useState("1000000"); // in microSTX
  const [status, setStatus] = useState("");

  async function handleConnect() {
    const res = await connect();
    const addr = res?.addresses?.[0]?.address ?? "";
    setAddress(addr);
    setConnected(true);
  }

  async function callDeposit() {
    setStatus("Submitting deposit...");
    try {
      const result = await request("stx_callContract", {
        contract: `${CONTRACT_ADDRESS}.${CONTRACT_NAMES.vault}`,
        functionName: "deposit",
        functionArgs: [Cl.uint(Number(daoId)), Cl.uint(Number(depositAmount))],
        network: "testnet",
      });
      setStatus(`Deposit submitted: ${result?.txid ?? "see wallet for tx id"}`);
    } catch (e) {
      setStatus(`Deposit failed: ${e.message}`);
    }
  }

  async function callDistributeEpoch() {
    setStatus("Triggering epoch distribution...");
    try {
      const result = await request("stx_callContract", {
        contract: `${CONTRACT_ADDRESS}.${CONTRACT_NAMES.payoutRouter}`,
        functionName: "distribute-epoch",
        functionArgs: [Cl.uint(Number(daoId))],
        network: "testnet",
      });
      setStatus(`Epoch distribution submitted: ${result?.txid ?? "see wallet for tx id"}`);
    } catch (e) {
      setStatus(`Distribution failed (likely too soon, or nothing to distribute): ${e.message}`);
    }
  }

  return (
    <div style={{ maxWidth: 720, margin: "2rem auto", fontFamily: "system-ui, sans-serif" }}>
      <h1>ReputationVault</h1>
      <p style={{ color: "#666" }}>
        A demo interface for a reputation-weighted contributor treasury vault built on FlowVault's
        programmable routing primitives on Stacks. Deposits auto-split into a contributor pool, an
        operational reserve, and an emergency fund. Contributor pool payouts are weighted by
        on-chain reputation, released only once per epoch, and can optionally be gated behind a
        milestone unlock.
      </p>

      <Section title="1. Connect wallet">
        {!connected ? (
          <button onClick={handleConnect}>Connect Stacks Wallet</button>
        ) : (
          <p>Connected as <code>{address}</code></p>
        )}
      </Section>

      <Section title="2. DAO context">
        <label>
          DAO ID:{" "}
          <input value={daoId} onChange={(e) => setDaoId(e.target.value)} style={{ width: 60 }} />
        </label>
        <p style={{ fontSize: 14, color: "#666" }}>
          Register a new DAO via <code>vault-core.register-dao</code> from a wallet or the Clarinet
          console first -- this demo assumes DAO id 1 already exists with a funded split.
        </p>
      </Section>

      <Section title="3. Deposit into the vault">
        <p style={{ fontSize: 14, color: "#666" }}>
          Funds are automatically split across contributor pool / operational reserve / emergency
          fund according to the DAO's configured basis-point ratios. No manual routing needed.
        </p>
        <label>
          Amount (microSTX):{" "}
          <input
            value={depositAmount}
            onChange={(e) => setDepositAmount(e.target.value)}
            style={{ width: 140 }}
          />
        </label>
        <div style={{ marginTop: 8 }}>
          <button onClick={callDeposit} disabled={!connected}>
            Deposit
          </button>
        </div>
      </Section>

      <Section title="4. Trigger reputation-weighted payout epoch">
        <p style={{ fontSize: 14, color: "#666" }}>
          Permissionless: anyone can call this once the epoch window has elapsed. Contributors are
          paid proportionally to their reputation score, not a fixed salary. If the DAO has gated
          mode on, this call fails until an authorized reporter unlocks the milestone flag.
        </p>
        <button onClick={callDistributeEpoch} disabled={!connected}>
          Distribute Epoch
        </button>
      </Section>

      {status && (
        <Section title="Status">
          <pre style={{ whiteSpace: "pre-wrap" }}>{status}</pre>
        </Section>
      )}

      <p style={{ fontSize: 12, color: "#999" }}>
        Reputation leaderboard, live pool balances, and milestone-gate controls are read directly
        from the read-only functions in vault-core.clar / reputation.clar / milestone-gate.clar --
        wire up a polling fetch against your Stacks API node of choice to populate them here.
      </p>
    </div>
  );
}
