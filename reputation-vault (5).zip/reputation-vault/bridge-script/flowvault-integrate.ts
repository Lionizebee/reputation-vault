import "dotenv/config";
import {
  makeContractCall,
  broadcastTransaction,
  callReadOnlyFunction,
  Cl,
  cvToValue,
  AnchorMode,
  PostConditionMode,
} from "@stacks/transactions";
import { StacksTestnet } from "@stacks/network";
import { FlowVault, tokenToMicro, DEFAULT_CONTRACTS } from "flowvault-sdk";

const PRIVATE_KEY_STX = process.env.PRIVATE_KEY_STX!;
const OUR_DEPLOYER = "ST25HBNK2PKDND65BXTGV8AP6NHE967GFS7KGDVYG";
const CONTRIBUTOR_ADDRESS = process.env.CONTRIBUTOR_ADDRESS!;

const DAO_ID = 1;
const network = new StacksTestnet();

function sleep(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// Polls the Hiro API until a transaction is confirmed (success or failed),
// so we never fire the next transaction before the previous one lands --
// avoids nonce collisions from broadcasting too fast back-to-back.
async function waitForConfirmation(txid: string, label: string, timeoutMs = 180000) {
  const start = Date.now();
  console.log(`     waiting for ${label} to confirm...`);
  while (Date.now() - start < timeoutMs) {
    const res = await fetch(`https://api.testnet.hiro.so/extended/v1/tx/${txid}`);
    const data = await res.json();
    if (data.tx_status === "success") {
      console.log(`     ${label} confirmed`);
      return true;
    }
    if (data.tx_status && data.tx_status.startsWith("abort")) {
      throw new Error(`${label} failed on-chain: ${data.tx_status}`);
    }
    await sleep(5000);
  }
  throw new Error(`Timed out waiting for ${label} to confirm`);
}

async function callOurContract(contractName: string, functionName: string, args: any[]) {
  const tx = await makeContractCall({
    contractAddress: OUR_DEPLOYER,
    contractName,
    functionName,
    functionArgs: args,
    senderKey: PRIVATE_KEY_STX,
    network,
    anchorMode: AnchorMode.Any,
    postConditionMode: PostConditionMode.Allow,
  });
  const result = await broadcastTransaction(tx, network);
  console.log(`  -> ${contractName}.${functionName} tx: ${result.txid}`);
  console.log(`     https://explorer.hiro.so/txid/${result.txid}?chain=testnet`);
  await waitForConfirmation(result.txid, `${contractName}.${functionName}`);
  return result;
}

async function readOurContract(contractName: string, functionName: string, args: any[]) {
  return callReadOnlyFunction({
    contractAddress: OUR_DEPLOYER,
    contractName,
    functionName,
    functionArgs: args,
    senderAddress: OUR_DEPLOYER,
    network,
  });
}

async function main() {
  if (!PRIVATE_KEY_STX) throw new Error("PRIVATE_KEY_STX missing from .env");
  if (!CONTRIBUTOR_ADDRESS) throw new Error("CONTRIBUTOR_ADDRESS missing from .env");

  console.log("=== Step 1: Register a DAO ===");
  try {
    await callOurContract("vault-core", "register-dao", [Cl.uint(7000), Cl.uint(2000), Cl.uint(1000)]);
  } catch (e: any) {
    console.log("  (may already exist -- continuing)", e.message?.slice(0, 200));
  }

  console.log("\n=== Step 2: Record a milestone ===");
  await callOurContract("reputation", "record-milestone", [
    Cl.uint(DAO_ID),
    Cl.principal(CONTRIBUTOR_ADDRESS),
    Cl.uint(100),
  ]);

  console.log("\n=== Step 3: Read reputation back ===");
  const repResult = await readOurContract("reputation", "get-reputation", [
    Cl.uint(DAO_ID),
    Cl.principal(CONTRIBUTOR_ADDRESS),
  ]);
  const reputation = Number(cvToValue(repResult));
  console.log(`  Contributor reputation score: ${reputation}`);

  const totalRepResult = await readOurContract("reputation", "get-total-reputation", [Cl.uint(DAO_ID)]);
  const totalReputation = Number(cvToValue(totalRepResult));
  console.log(`  Total DAO reputation: ${totalReputation}`);

  const contributorShareBps = totalReputation > 0 ? Math.floor((reputation / totalReputation) * 10000) : 10000;
  console.log(`  Contributor share: ${(contributorShareBps / 100).toFixed(2)}%`);

  console.log("\n=== Step 4: Compute FlowVault routing numbers ===");
  const depositAmountUsdc = "10";
  const depositMicro = tokenToMicro(depositAmountUsdc);

  const lockAmount = (depositMicro * 10n) / 100n;
  const contributorPoolAmount = (depositMicro * 70n) / 100n;
  const splitAmount = (contributorPoolAmount * BigInt(contributorShareBps)) / 10000n;

  console.log(`  Deposit: ${depositAmountUsdc} USDCx`);
  console.log(`  LOCK: ${lockAmount} micro-USDCx`);
  console.log(`  SPLIT to contributor: ${splitAmount} micro-USDCx`);

  console.log("\n=== Step 5: Call the REAL FlowVault contract ===");
  const vault = new FlowVault({
    network: "testnet",
    senderKey: PRIVATE_KEY_STX,
    ...DEFAULT_CONTRACTS.testnet,
  });

  const currentBlock = await vault.getCurrentBlockHeight(OUR_DEPLOYER);
  const lockUntilBlock = currentBlock + 144;

  console.log("  Setting routing rules on FlowVault...");
  const rulesResult: any = await vault.setRoutingRules({
    lockAmount,
    lockUntilBlock,
    splitAddress: CONTRIBUTOR_ADDRESS,
    splitAmount,
  });
  console.log("  setRoutingRules tx:", rulesResult);
  const rulesTxId = rulesResult.txId || rulesResult.txid || rulesResult.id;
  if (rulesTxId) await waitForConfirmation(rulesTxId, "setRoutingRules");

  console.log("  Depositing into FlowVault...");
  const depositResult: any = await vault.deposit(depositMicro);
  console.log("  deposit tx:", depositResult);
  const depositTxId = depositResult.txId || depositResult.txid || depositResult.id;
  if (depositTxId) {
    console.log(`  https://explorer.hiro.so/txid/${depositTxId}?chain=testnet`);
    await waitForConfirmation(depositTxId, "deposit");
  }

  console.log("\n=== Step 6: Confirm final state ===");
  const state = await vault.getVaultState(OUR_DEPLOYER);
  console.log(state);

  console.log("\nDone. Real FlowVault transaction complete.");
}

main().catch((err) => {
  console.error("Integration script failed:", err);
  process.exit(1);
});
