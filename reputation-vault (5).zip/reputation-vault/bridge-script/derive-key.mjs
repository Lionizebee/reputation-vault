// Run this locally: it derives your Stacks private key from your seed
// phrase and prints ONLY the private key (never the phrase) to your own
// terminal. Nothing is sent anywhere -- @stacks/wallet-sdk does this
// entirely offline, on your machine.
//
// Usage:
//   node derive-key.mjs "word1 word2 word3 ... word24"

import { generateWallet } from "@stacks/wallet-sdk";

async function main() {
  const mnemonic = process.argv.slice(2).join(" ").trim();
  if (!mnemonic) {
    console.error("Usage: node derive-key.mjs \"your seed phrase here\"");
    process.exit(1);
  }

  const wallet = await generateWallet({
    secretKey: mnemonic,
    password: "",
  });

  const account = wallet.accounts[0];
  console.log("\nSTX address (should match your Leather address):");
  console.log(account.stxPrivateKey ? "(private key found)" : "(none found)");
  console.log("\nYour private key (copy this into bridge-script/.env as PRIVATE_KEY_STX):");
  console.log(account.stxPrivateKey);
}

main();
